<?php
session_start();

if(isset($_SESSION['username'])){

	//koneksi terpusat
	include "config/koneksi.php";
	
    // get the HTML
    ob_start();	
	$comot=mysql_query("SELECT * FROM tbl_pesan, tbl_paket, tbl_hotel, tbl_user WHERE tbl_pesan.id_user=tbl_user.id_user AND
						tbl_pesan.id_paket=tbl_paket.id_paket AND tbl_pesan.id_hotel=tbl_hotel.id_hotel AND id_pesan=".$_GET['id']);
	$isi_tbl=mysql_fetch_array($comot);
	
	$total_harga = $isi_tbl['harga_paket']+$isi_tbl['harga'];
    $num = 'BM00'.$isi_tbl['id_pesan'].' - ('.$isi_tbl['tgl_pesan'].')';
    $nom = $isi_tbl['nama_user'];
    $date = date("d M Y");
?>
<style type="text/css">
<!--
    div.zone { border: none; border-radius: 6mm; background: #FFFFFF; border-collapse: collapse; padding:3mm; font-size: 2.7mm;}
    h1 { padding: 0; margin: 0; color: #DD0000; font-size: 7mm; }
    h2 { padding: 0; margin: 0; color: #222222; font-size: 5mm; position: relative; }
-->
</style>
<page format="105x200" orientation="L" backcolor="#AAAACC" style="font: arial;">
    <div style="rotate: 90; position: absolute; width: 100mm; height: 4mm; left: 195mm; top: 0; font-style: italic; font-weight: normal; text-align: center; font-size: 2.5mm;">
        Lodging prices may change at any time, with certain conditions.
    </div>
    <table style="width: 99%;border: none;" cellspacing="4mm" cellpadding="0">
        <tr>
            <td colspan="2" style="width: 100%">
                <div class="zone" style="height: 34mm;position: relative;font-size: 5mm;">
                    <div style="position: absolute; right: 3mm; top: 3mm; text-align: right; font-size: 4mm; ">
                        <b><?php echo $nom; ?></b><br>
                    </div>
                    <div style="position: absolute; right: 3mm; bottom: 3mm; text-align: right; font-size: 4mm; ">
                        Package Type : <b><?php echo $isi_tbl['nama_paket']; ?></b><br>
                        Total        : <b><?php echo $total_harga; ?> IDR</b><br>
                        Booking Code : <b><?php echo $num; ?></b><br>
                        Tour Date    : <b><?php echo $isi_tbl['tgl_tour']; ?></b><br>
                    </div>
                    <img src="images/y.png" width="100" height="99" />
					<span style="position: absolute; left: 32mm; top: 10mm; font-size: 28px; color: red">BeMount</span><br />
                    <span style="position: absolute; left: 32mm; top: 18mm; font-size: 16px;">Depok, <?php echo $date; ?></span>
                	
                </div>
            </td>
        </tr>
        <tr>
            <td style="width: 25%;">
                <div class="zone" style="height: 40mm;vertical-align: middle;text-align: center;">
                    <qrcode value="<?php echo $num."\n".$nom."\n".$date; ?>" ec="Q" style="width: 37mm; border: none;" ></qrcode>
                </div>
            </td>
            <td style="width: 75%">
                <div class="zone" style="height: 40mm;vertical-align: middle; text-align: justify">
                    <b>Provisions : </b><br>
					1. Changes to packages and lodging, please contact our contact person on the website, and can only be done 5 days before the end of the tour. Less than that change cannot be made. <br>
                    2. Booking cancellations can be made 7 days before the deadline of the tour that has been booked. Fees that have been transferred will be returned with a discount of 10% of the total cost and must confirm in advance through our contact person. <br>
                    3. For lodging costs that have not been calculated at the time of booking, we will confirm to your account 7 days before the end of the tour. And can print tickets after that day. <br>
                </div>
            </td>
        </tr>
    </table>
</page>
<?php
     $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'fr', true, 'UTF-8', 0);
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output('ticket00'.$isi_tbl['id_pesan'].'-'.date('Y/m/d').'.pdf');
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

}else{
	session_destroy();
	header('Location:formRegistrasi.php?status=Silahkan Login');
}
?>
