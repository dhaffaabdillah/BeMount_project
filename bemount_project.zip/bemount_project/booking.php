<?php session_start();

if(isset($_SESSION['username'])){

	//koneksi terpusat
	include "config/koneksi.php";
	$username=$_SESSION['username'];
	
	if(isset($_POST['Submit']))
	{
		mysql_query("INSERT INTO tbl_pesan (id_user, id_paket, id_hotel, tgl_pesan, tgl_tour, status)
				value ('$_POST[id_user]','$_POST[paket]','$_POST[hotel]',NOW(),'$_POST[dateTour]','$_POST[status]')") or die(mysql_error());
		
		header("location:bookingList.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="css/metro-bootstrap.css" rel="stylesheet">
    <link href="css/metro-bootstrap-responsive.css" rel="stylesheet">
    <link href="css/iconFont.css" rel="stylesheet">
    <link href="css/docs.css" rel="stylesheet">


    <!-- Load JavaScript Libraries -->
    <script src="js/jquery/jquery.min.js"></script>
    <script src="js/jquery/jquery.widget.min.js"></script>
    <script src="js/jquery/jquery.mousewheel.js"></script>

    <!-- Metro UI CSS JavaScript plugins -->
    <script src="js/load-metro.js"></script>

    <!-- Local JavaScript -->
    <script src="js/docs.js"></script>
    
    <style>
    </style>

<title>Booking your package</title>
</head>


<body class="metro">
	<header class="bg-darkCobalt" data-load="atasan.php"></header>
    
    <div class="" data-load="sampul.html"></div>
	
<?php
	$query	=mysql_query("SELECT * FROM tbl_user WHERE username='$username'");
	$tampil	=mysql_fetch_array($query);

	echo "<script language=\"JavaScript\" src=\"comboBox.js\"></script>";
?>
    
    <!-- ---------------------------------------- ISI TAB ------------------------------------- -->
    <div class="container">
        <div class="grid">
		<div class="row">
			<div class="span4">
				<legend>Set a Date</legend>
                <div class="calendar" id="cal-events"></div>
				<div id="calendar-output2"></div>
            </div>
			<script>
				$(function(){
					var cal = $("#cal-events").calendar({
						multiSelect: false,
						click: function(d){
							var out = $("#dateTour").val("");
							out.val(d);
						}
					});
					cal.calendar('setDate', '2013-10-21');
					cal.calendar('setDate', '2013-10-2');
				})
            </script>
			
            <div class="span6">
                <form name="formBooking" method="post" action="#">
                    <fieldset>
                        <legend>Fill out this form on below</legend>
                        <lable>Complete Name</lable>
                        <div class="input-control text" data-role="input-control">
							<input type="hidden" name="id_user" readonly
							 value="<?php echo $tampil['id_user'];?>">
                            <input type="text" name="nama" readonly
							 value="<?php echo $tampil['nama_user'];?>">
                        </div>
						<lable>Date</lable>
                        <div class="input-control text" data-role="input-control">
                            <input id="dateTour" type="text" name="dateTour" required value="" placeholder="Auto input if you have clicked the date beside form.">
                            <button class="btn-clear" tabindex="-1"></button>
                        </div>
						
						<label>Select Destination of Beach or Mountain</label>
                        <div class="input-control select" data-role="input-control">						
							<select name='tujuan' onChange='DinamisDaerah(this);' class="cmb">
							<option value="">Select Destination</option>
							<?php
								$query = "select * from tbl_daerah";
								$result = mysql_query($query);
								while ($set=mysql_fetch_array($result))
								{
									echo "<option value=$set[kode]>$set[daerah]</option>";
								}
								echo"</select>";
							?>
						</div>
						
						<label>Select a lodging</label>
						<div id="hotel" class="input-control select" data-role="input-control">
							<select class="cmb">
								<option value="">Select a hotel</option>
							</select>
                        </div>
						
						<label>Select package category</label>
                        <div class="input-control select" data-role="input-control">						
							<select name='kategori' onChange='DinamisKategori(this);' class="cmb">
							<option value="">Select Category</option>
							<?php
								$query = "select * from tbl_kategori";
								$result = mysql_query($query);
								while ($set=mysql_fetch_array($result))
								{
									echo "<option value=$set[id_kategori]>$set[kategori]</option>";
								}
								echo"</select>";
							?>
						</div>
						
						<label>Select a Package</label>
						<div id="paket" class="input-control select" data-role="input-control">
							<select class="cmb">
								<option value="">Select Package</option>
							</select>
                        </div>
						<label>Do you want to cash?</label>
						<div>
							<div class="input-control radio" data-role="input-control">
                                <label>
                                <input type="radio" name="status" value="S3" />
                                <span class="check"></span>Yes
                                </label>
                            </div>
						</div>
						<div>
                            <div class="input-control radio" data-role="input-control">
                                <label>
                                <input type="radio" name="status" value="S1" checked />
                                <span class="check"></span>No, I wan't to transfer
                                </label>
                            </div>
						</div>
						
                        <input type="submit" name="Submit" value="Next">
                    </fieldset>
                </form>
            </div>
		</div>
        </div>
    </div>
    <!-- ---------------------------------------- ISI TAB ------------------------------------- -->
    
    <footer class="dark" data-load="bawahan.html"></footer>
</body>
</html>
<?php
}else{
	session_destroy();
	header('Location:formRegistrasi.php?status=Silahkan Login');
}
?>