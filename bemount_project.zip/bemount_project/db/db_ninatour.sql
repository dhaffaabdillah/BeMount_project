-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2020 at 06:00 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ninatour`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(20) NOT NULL,
  `no_hp` varchar(12) NOT NULL,
  `no_tlp` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `negara` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `alamat`, `kota`, `no_hp`, `no_tlp`, `email`, `content`, `negara`) VALUES
(1, '<p>Jl Raya Tapos</p>\r\n<p>Kecamatan Tapos</p>\r\n', 'Depok', '081615655842', '0351-4477624', 'dhaffdhaff1@gmail.com', '<p>An agent travel to take you on Beach or beautiful mountain in West Java</p>', 'Indonesia');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE `komentar` (
  `id_komentar` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `komentar` text NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`id_komentar`, `nama`, `komentar`, `waktu`) VALUES
(3, 'Test', 'fggdd', '2020-11-17 08:42:00'),
(4, 'd', 'test comment form', '2020-12-17 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `setup_about`
--

CREATE TABLE `setup_about` (
  `id_about` int(11) NOT NULL,
  `kat_about` varchar(30) NOT NULL,
  `judul_about` varchar(50) NOT NULL,
  `konten_about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_about`
--

INSERT INTO `setup_about` (`id_about`, `kat_about`, `judul_about`, `konten_about`) VALUES
(2, 'profil', 'BeMount profile', '<p>BeMount&nbsp;adalah is an agent travel to take you on beautiful beach or mountain in West Java.Come join and holiday with us!</p>'),
(7, 'pembayaran', 'Payment Method', '<p>There are 2 payment methods First, you can pay cash on the place Or you can transfer to us. \r\nwith the following conditions :</p>\r\n<ol>\r\n<li>Cash\r\n<ul>\r\n<li>Direct payments are specifically for customers who are close to our office</li>\r\n<li>Payment is made 5 days before departure.</li>\r\n<li>Payment terms must be attached to the invoice and ticket that has been booked.</li>\r\n<li>Payment will be served during working hours.</li>\r\n</ul>\r\n</li>\r\n<li>Payment via Transfer\r\n<ul>\r\n<li>Payment via Transfer\r\nThis payment is intended for customers from outside the city as well as who want a practical process.</li>\r\n<li>Payment must be received by us no later than 5 days before the day of tour departure.</li>\r\n<li>Transfers can be made to the following account numbers:<ul>\r\n<li>BNI : 0123456789 a/n&nbsp;Dhaffa Abdillah Hakim</li>\r\n<li>Mandiri :&nbsp;0123456789&nbsp; a/n&nbsp;Ekky Mulia Lasardi</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n</ol>'),
(8, 'syarat', '', '<p>These terms and conditions are useful to assist you in making a booking in accordance with the conditions that we have made. So that you will not feel lost and wrong in choosing a package or lodging later. Please pay attention to the provisions that have been made and continue with making a booking.</p>'),
(12, 'reservasi', '', '<ol>\r\n<li>Before booking a reservation, you must&nbsp;<a href=\"formRegistrasi.php\">Login</a>&nbsp;First into this site.</li>\r\n<li>If you doesn\'t have an account, you must&nbsp;<a href=\"formRegistrasi.php\">Register</a></li>\r\n<li>After login or have an account, edit or complete your profile.</li>\r\n<li>After completing your profile, you can book or reservation</li>\r\n<li>Then, choose package or destination.</li>\r\n<li>If you select the cash on place payment, pay at the place. Or, you can select using transfer payment</li>\r\n</ol>'),
(13, 'syarat', '\r\nHotel Capacity Requirements', '<p>Maximum number of visitors per room:</p>\r\n<ul style=\"list-style-type: circle;\">\r\n<li>Standard Class, max. 2 persons</li>\r\n<li>Superior Class, max. 2 persons</li>\r\n<li>Delux class, mom. 2/4 people *</li>\r\n<li>\r\nFamily Suite Class, max 7 Persons</li>\r\n</ul>\r\n<p>* conditions can change at any time</p>'),
(14, 'syarat', 'Conditions for Choosing Lodging', '<p> For bookings, it is expected to be checked before actually making a booking, meaning: </p>\r\n<ul style = \"list-style-type: circle;\">\r\n<li> Adjust the accommodation with the place where you will be traveling. </li>\r\n<li> If you choose a tour package with the One-Way type, then on the select lodging form, please select the \"No Stay\" option. </li>\r\n<li> In order to be more precise in choosing an accommodation, first look at where the tour package is located. </li>\r\n</ul>'),
(15, 'syarat', '\r\nBooking Terms', '<ul style = \"list-style-type: circle;\">\r\n<li> Changes to packages and lodging, please contact our contact person on the website, and can only be done 5 days before the day of tour departure. Less than that the changes cannot be made. </li>\r\n<li> Booking cancellations can be made 7 days before the tour departure date that has been booked. Fees that have been transferred will be returned with a discount of 10% of the total cost and must confirm in advance through our contact person. </li>\r\n<li> For lodging costs that have not been calculated at the time of booking, we will confirm it to your account 7 days before the day of tour departure. And can print tickets after that day. </li>\r\n</ul>');

-- --------------------------------------------------------

--
-- Table structure for table `setup_dasboard`
--

CREATE TABLE `setup_dasboard` (
  `id_dasboard` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `konten` text NOT NULL,
  `gambar` text NOT NULL,
  `waktu` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_dasboard`
--

INSERT INTO `setup_dasboard` (`id_dasboard`, `nama`, `konten`, `gambar`, `waktu`) VALUES
(9, 'BeMount ', '<p>BeMount is an agent travel to take you to best Beach or Mountain in West Java</p>\r\n<p>Start reservation and schedule your holiday / travel</p>\r\n<p>Let\'s come join with us!</p>', '/GUNUNG/Gunung-Ciremai.jpg', '2020-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `setup_slide`
--

CREATE TABLE `setup_slide` (
  `id_slide` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `konten` text NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_slide`
--

INSERT INTO `setup_slide` (`id_slide`, `judul`, `konten`, `gambar`) VALUES
(1, 'Covid-19 Promo Edition, Up to 30%', '<p>Go vacation with us, and use the promo up to 30%. For more information,<a href=\"contact.php\"> contact to us</a></p>', 'Bromo.jpg'),
(2, 'How to reservation?', '<p>How to reservation? Just check <a href=\"aboutUs.php?post=reservasi\">this page</a> to reservation.</p>', 'pesona telaga sarangan.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `setup_sumbar`
--

CREATE TABLE `setup_sumbar` (
  `id_sumbar` int(11) NOT NULL,
  `kat_sumbar` varchar(30) NOT NULL,
  `judul_sumbar` varchar(50) NOT NULL,
  `konten_sumbar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_sumbar`
--

INSERT INTO `setup_sumbar` (`id_sumbar`, `kat_sumbar`, `judul_sumbar`, `konten_sumbar`) VALUES
(5, 'profil', '', '<p style=\"text-align: justify;\"><strong>West Java</strong>West Java (Indonesian: Jawa Barat; Sundanese: ᮏᮝ ᮊᮥᮜᮧᮔ᮪) is a province of Indonesia on the western part of the island of Java, with its provincial capital in Bandung. West Java is bordered by the province of Banten and the country\'s capital region of Jakarta to the west, the Java Sea to the north, the province of Central Java to the east and the Indian Ocean to the south. The province is the native homeland of the Sundanese people, the second-largest ethnic group in Indonesia after the Javanese.\r\n\r\nWest Java was one of the first eight provinces of Indonesia formed following the country\'s independence proclamation and was later legally re-established on 14 July 1950. In 1966, the city of Jakarta was split off from West Java as a \'special capital region\' (Daerah Khusus Ibukota), with a status equivalent to that of a province,[4] while in 2000 the western parts of the province were in turn split away to form a separate Banten province.\r\n\r\nEven following these split-offs, West Java is the most populous province of Indonesia with a population of 49,935,858 as of mid-2020.[5] The province\'s largest cities, Bekasi and Bandung, are the third and fourth most populous cities proper in Indonesia respectively. As a satellite city within the Jakarta metropolitan area, Bekasi experiences highly rapid population growth, having surpassed Bandung in 2012. Nonetheless, Bandung remains one of the most densely populated cities proper in the world, while Bekasi and Depok, both satellites of Jakarta, are respectively the seventh and tenth most populous suburbs in the world.[6]</p>'),
(6, 'profil', 'West Java Geography ', '<p style=\"text-align: justify;\">West Java borders Jakarta and Banten province to the west and Central Java to the east. To the north is the Java Sea. To the south is the Indian Ocean. Unlike most other provinces in Indonesia which have their capitals in coastal areas, the provincial capital, Bandung, is located in the mountainous area in the centre of the province. Banten Province was formerly part of West Java but was created a separate province in 2000. West Java, in the densely populated western third of Java, is home to almost one out of every five Indonesians.\r\n\r\nWest Java and Banten provinces, as a part of the Pacific Ring of Fire, have more mountains and volcanoes than any of the other provinces in Indonesia. The vast volcanic mountainous region of inland West Java is traditionally known as Parahyangan (also known as Priangan or Preanger) which means \"The abode of hyangs (gods)\". It is considered as the heartland of the Sundanese people. The highest point of West Java is the stratovolcano Mount Cereme (3,078 meters) bordering Kuningan and Majalengka Regencies. West Java has rich and fertile volcanic soil. Agriculture, mostly traditional dry rice cultivation (known as ladang or huma), has become the primary way of life of traditional Sundanese people. Since the era of the Dutch East India Company (VOC), West Java has been known as a productive plantation area for coffee, tea, quinine, and many other cash crops. The mountainous region of West Java is also a major producer of vegetables and decorative flowering plants. The landscape of the province is one of volcanic mountains, steep terrain, forest, mountains, rivers, fertile agricultural land, and natural sea harbours.[14]\r\n\r\nFlowing through Bandung Basin to the northeast is Citarum River, the longest and most important river in the province. This 300-km long river is the site of three dams, namely Cirata Dam, Saguling Dam, and Jatiluhur Dam. The river is heavily polluted by industrial and household sewage to the point that it has been called \'the world\'s dirtiest river\' by some sources.</p>'),
(7, 'sejarah', '', '<p style=\"text-align: justify;\">The oldest human inhabitant archaeological findings in the region were unearthed in Anyer (the western coast of Java) with evidence of bronze and iron metallurgical culture dating to the first millennium AD.[7] The prehistoric Buni culture (near present-day Bekasi) clay pottery were later developed with evidence found in Anyer to Cirebon. Artefacts (dated from 400 BC — AD 100), such as food and drink containers, were found mostly as burial gifts.[7] There is also archaeological evidence in Batujaya Archaeological Site dating from the 2nd century[citation needed] and, according to Dr Tony Djubiantono, the head of Bandung Archaeology Agency, Jiwa Temple in Batujaya, Karawang, West Java was also built around this time.[citation needed]\r\n\r\nOne of the earliest known[clarification needed] recorded history in Indonesia is from the former Tarumanagara kingdom, where seven fourth-century stones are inscribed in Wengi letters (used in the Pallava period) and in Sanskrit describing the kings of the kingdom Tarumanagara.[7] Records of Tarumanegara\'s administration lasted until the sixth century, which coincides with the attack of Srivijaya, as stated in the Kota Kapur inscription (AD 686).\r\n\r\nThe Sunda Kingdom subsequently became the ruling power of the region, as recorded on the Kebon Kopi II inscription (AD 932).[7]\r\n\r\nAn Ulama, Sunan Gunung Jati, settled in Cirebon, intending to spread the word of Islam in the pagan town. Meanwhile, the Sultanate of Demak in central Java grew to an immediate threat against the Sunda kingdom. To defend against the threat, Prabu Surawisesa Jayaperkosa signed a treaty (known as the Luso-Sundanese Treaty) with the Portuguese in 1512. In return, the Portuguese were granted an accession to build fortresses and warehouses in the area, as well as forming trading agreements with the kingdom. This first international treaty of Sunda Kingdom with the Europeans was commemorated by the placement of the Padrao stone monument at the bank of the Ciliwung River in 1522.\r\n\r\nAlthough the treaty with the Portuguese had been established, it could not come to realisation. Sunda Kalapa harbour fell under the alliance of the Sultanates of Demak and Cirebon (former vassal state of Sunda kingdom) in 1524 after their troops under Paletehan alias Fadillah Khan had conquered the city. In 1524-1525, their troops under Sunan Gunung Jati also seized the port of Banten and established the Sultanate of Banten which was affiliating with Demak. The war between the Sunda kingdom with Demak and Cirebon sultanates continued for five years until a peace treaty was made in 1531 between King Surawisesa and Sunan Gunung Jati. From 1567 to 1579, under the last king Raja Mulya, alias Prabu Surya Kencana, the Sunda kingdom declined, essentially under pressure from Sultanate of Banten. After 1576, the kingdom could not maintain its capital at Pakuan Pajajaran (present-day Bogor), and gradually the Sultanate of Banten took over the former Sunda kingdom\'s region. The Mataram Sultanate from central Java also seized the Priangan region, the southeastern part of the kingdom.\r\n\r\nIn the 16th century, the Dutch and the British trading companies established their trading ships in westtern Java after the fall of Sultanate of Banten. For the next three hundred years, western Java fell under the Dutch East Indies\' administration. West Java was officially declared as a province of Indonesia in 1950, referring to a statement from Staatblad number 378. On 17 October 2000, as part of nationwide political decentralisation, Banten was separated from West Java and made into a new province. There have been recent proposals to rename the province Pasundan (\"Land of the Sundanese\") after the historical name for West Java.[8][9]</p>'),
(9, 'wisata', '', '<p style=\"text-align: justify;\">Tourism is an important industry in West Java, and the Bandung and Puncak areas have long been known as popular weekend destinations for Jakartans. Today, Bandung has developed into a shopping destination, popular not only among locals, but also with neighbouring Malaysian and Singaporean visitors.[16] The history-rich coastal city of Cirebon is also a cultural tourism destination since the city has several kratons and historical sites such as Gua Sunyaragi. Other tourist destinations include the Bogor Botanical Garden, Safari Park of Indonesia, Tangkuban Perahu crater, Pelabuhanratu Bay, Ciater hot springs, Kawah Putih crater to the south of Bandung, Pangandaran beach, and various mountain resorts in Cianjur, Garut, Tasikmalaya, and Kuningan.</p>'),
(13, 'kuliner', '', '<p>Sundanese cuisine is the cuisine of the Sundanese people of West Java, and Banten, Indonesia. It is one of the most popular foods in Indonesia. Sundanese food is characterised by its freshness; the famous lalab eaten with sambal and also karedok demonstrate the Sundanese fondness for fresh raw vegetables. Unlike the rich and spicy taste, infused with coconut milk and curry of Minangkabau cuisine, the Sundanese cuisine displays the simple and clear taste; ranged from savoury salty, fresh sourness, mild sweetness, to hot and spicy.\r\n\r\nSambal terasi is the most important and the most common condiment in Sundanese cuisine, and eaten together with lalab or fried tofu and tempeh. Sayur Asem vegetable tamarind soup is probably the most popular vegetable soup dish in Sundanese cuisine. Another popular soup is Soto Bandung, a soup of beef and daikon radish, and mie kocok noodle soup with beef meat and kikil.</p>'),
(15, 'budaya', 'Art in West Java', '<p style=\"text-align: justify;\">The Sundanese share the Java island with the Javanese and primarily live in West Java. Although the Sundanese live on the same island as the Javanese, their culture is distinct and likewise consider themselves to live in a separate cultural area called Pasundan or Tatar Sunda. Someone moving from West Java to Central or East Java is literally said to be moving from Sunda to Java worlds. Bandung is considered as the cultural heartland of Sundanese people, and many indigenous Sundanese artforms were developed in this city. The nearby province of Banten is similar in this regard and is also considered to be part of Pasundan as well.</p>'),
(16, 'budaya', 'Culture in West Java', '<p style=\"text-align: justify;\">Gamelan orchestra\r\n\r\nGamelan Degung Orchestra\r\nThe musical arts of Sunda, which is an expression of the emotions of Sundanese culture, express politeness and grace of Sundanese. Degung orchestra consists of Sundanese gamelan.\r\n\r\nIn addition to the Sundanese forms of Gamelan in Parahyangan, the region of Cirebon retains its own distinct musical traditions. Amongst Cirebons\' varying Gamelan ensembles the two most frequently heard are Gamelan Pelog (a non-equidistant heptatonic tuning system) and Gamelan Prawa (a semi-equidistant pentatonic tuning system). Gamelan Pelog is traditionally reserved for Tayuban, Wayang Cepak, and listening and dance music of the Kratons in Cirebon, while Gamelan Prawa is traditionally reserved for Wayang Purwa.\r\n\r\nCirebon also retains specialised Gamelan ensembles including Sekaten, which is played in the Kratons to mark important times in the Islamic calendar, Denggung, also a Kraton ensemble, which is believed to have some \"supernatural powers\", and Renteng, an ensemble found in both Cirebon and Parahyangan known for its loud and energetic playing style.\r\n\r\nZither ensembles\r\nTembang Sunda is a genre of Sundanese vocal music accompanied by a core ensemble of two Kacapi (zither) and a Suling (bamboo flute). The music and poetry of tembang Sunda are closely associated with the Parahyangan, the highland plateau that transverses the central and southern parts of Sunda. The natural environment of Priangan, an agricultural region surrounded by mountains and volcanoes, is reflected in some songs of the tembang Sunda.[21]\r\n\r\nKacapi suling is tembang Sunda minus vocal.\r\n\r\nTarawangsa is a genuine popular art is performed on ensemble consists of tarawangsa (a violin with an end pin) and the jentreng (a kind of seven-stringed zither). It is accompanied by a secret dance called Jentreng. The dance is a part of a ritual celebrating the goddess of paddy Dewi Sri. Its ceremonial significance is associated with a ritual of thanksgiving associated with the rice harvest. Tarawangsa can also be played for healing or even purely for entertainment.\r\n\r\nBamboo ensembles\r\n\r\nAngklung as a Masterpiece of Oral and Intangible Heritage of Humanity.\r\nThe three main types of Sundanese bamboo ensembles are angklung, calung, karinding and arumba. The exact features of each ensemble vary according to context, related instruments, and relative popularity.\r\n\r\nAngklung is a generic term for sets of tuned, shaken bamboo rattles. Angklung consists of a frame upon which hang several different lengths of hollow bamboo. Angklungs are played like handbells, with each instrument played to a different note. Angklung rattles are played in interlocking patterns, usually with only one or two instruments played per person. The ensemble is used in Sundanese processions, sometimes with trance or acrobatics. Performed at life-cycle rituals and feasts (hajat), angklung is believed to maintain balance and harmony in the village. In its most modern incarnation, angklung is performed in schools as an aid to learning music.\r\n\r\nThe Angklung received international attention when Daeng Soetigna, from Bandung, expanded the angklung notations not only to play traditional pélog or sléndro scales but also diatonic scale in 1938. Since then, angklung is often played together with other Western musical instruments in an orchestra. One of the first well-known performances of angklung in an orchestra was during the Bandung Conference in 1955.\r\n\r\nLike those in angklung, the instruments of the calung ensemble are of bamboo, but each consists of several differently tuned tubes fixed onto a piece of bamboo; the player holds the instrument in his left hand and strikes it with a beater held in his right. The highest-pitched calung has the highest number of tubes and the densest musical activity; the lowest-pitched, with two tubes, has the least. Calung is nearly always associated with earthy humour, and is played by men.\r\n\r\nArumba refers to a set of diatonically tuned bamboo xylophones, often played by women. It is frequently joined by modern instruments, including a drum set, electric guitar, bass, and keyboards.\r\n\r\nTheatre\r\n\r\nWayang Golek, traditional Sundanese puppetry.\r\nWayang golek is a traditional form of puppetry from Sunda. Unlike the better-known leather shadow puppets (wayang kulit) found in the rest of Java and Bali, wayang golek puppets are made from wood and are three-dimensional, rather than two. They use a banana palm in which the puppets stand, behind which one puppeteer (dalang) is accompanied by his gamelan orchestra with up to 20 musicians. The gamelan uses a five-note scale as opposed to the seven-note western scale. The musicians are guided by the drummer, who in turn is guided by signals from the puppet master dalang gives to change the mood or pace required. Wayang golek are used by the Sundanese to tell the epic play \"Mahabarata\", and various other morality-type plays.\r\n\r\nSandiwara Sunda or Longser is a type of sandiwara or folk teather performed in Sundanese and presenting Sundanese themes, folklores and stories.\r\n\r\nDance\r\n\r\nJaipongan, traditional dance of sundanese people\r\nMain article: Sundanese dance\r\nSundanese dance shows the influence of the many groups that have traded and settled in the area over the centuries, and includes variations from graceful to dynamic syncopated drumming patterns, quick wrist flicks, sensual hip movements, and fast shoulder and torso isolations. Jaipongan is probably the most popular traditional social dance of Sundanese people. It can be performed in solo, grups, or pair. The Tari Merak (Peafowl Dance) is a female dance inspired by the movements of a peafowl and its feathers blended with the classical movements of the Sundanese dance.\r\n\r\nFolktales and legend stories\r\n\r\nA painting depicting Nyai Loro Kidul\r\nThere are stories and folktales transcribed from Pantun Sunda stories.[22] Among the most well-known folktale and stories are:\r\n\r\nMundinglaya Dikusumah, which tells of Mundinglaya visiting Jabaning Langit to find layang Salaka Domas. It is a symbolic story of Surawisesa visiting Malaka to establish a peace treaty with the Portuguese before 1522.\r\nLutung Kasarung, tells the life of a beautiful princess, in the era of Pasir Batang kingdom, a vassal of Sunda kingdom. She faces the evil of her older sister willing to seize her right as a queen.[23]\r\nCiung Wanara, tells of the fight of two princes of Sunda kingdom and the history of Cipamali river (present-day Brebes river) as a boundary between Sundanese and Javanese territories.\r\nSangkuriang, which tells the story of the creation of Mount Tangkuban Parahu and the ancient lake Bandung.[24]\r\nNyai Loro Kidul (also spelt Nyi Roro Kidul) is a legendary female spirit or deity, known as the Queen of the Southern Sea of Java (Indian Ocean or Samudra Kidul south of Java island) in Sundanese as well in Javanese mythology.\r\nLiterature\r\nOld Sundanese literature, among others, are:\r\n\r\nBujangga Manik, which was written on 29 palm leaves and kept in the Bodleian Library in Oxford since 1627, mentioning more than 450 names of places, regions, rivers and mountains situated on Java island, Bali island and Sumatra island.[25]\r\nCarita Parahyangan, telling Sundanese kings and kingdoms from the pre-Islamic period.[25]\r\nSiksakandang Karesian, providing the reader with all kinds of religious and moralistic rules, prescriptions and lessons</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `user_admin` varchar(20) NOT NULL,
  `pass_admin` varchar(20) NOT NULL,
  `level` varchar(20) NOT NULL,
  `aktif` varchar(20) NOT NULL DEFAULT 'Y',
  `nama` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_admin`, `pass_admin`, `level`, `aktif`, `nama`) VALUES
('admin', 'admin', 'admin', 'Y', 'Administrator'),
('operator', 'operator', 'operator', 'Y', 'Operator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bukti`
--

CREATE TABLE `tbl_bukti` (
  `id_bukti` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bukti`
--

INSERT INTO `tbl_bukti` (`id_bukti`, `id_pesan`, `file`) VALUES
(1, 1, 'cropped-GravityNew-01.png'),
(2, 2, 'BI.png'),
(3, 2, 'cropped-GravityNew-01.png'),
(4, 5, '12142152_1510134265969536_6869965_n.jpg'),
(5, 7, 'logo rpl.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_daerah`
--

CREATE TABLE `tbl_daerah` (
  `id_daerah` int(11) NOT NULL,
  `kode` varchar(8) NOT NULL,
  `daerah` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_daerah`
--

INSERT INTO `tbl_daerah` (`id_daerah`, `kode`, `daerah`) VALUES
(1, 'PGRGO', 'Pangarango Mountain'),
(3, 'CRM', 'Ciremai Mountain'),
(4, 'PSRPTH', 'Pasir Putih Beach'),
(5, 'CMJ', 'Cimaja Beach'),
(6, 'PGDRN', 'Pangandaran Beach'),
(7, 'PRH', 'Tangkuban Perahu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hotel`
--

CREATE TABLE `tbl_hotel` (
  `id_hotel` int(11) NOT NULL,
  `kd_daerah` varchar(6) NOT NULL,
  `hotel` varchar(100) NOT NULL,
  `bintang` tinyint(1) NOT NULL,
  `harga` int(11) NOT NULL,
  `ket_hotel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_hotel`
--

INSERT INTO `tbl_hotel` (`id_hotel`, `kd_daerah`, `hotel`, `bintang`, `harga`, `ket_hotel`) VALUES
(1, 'PGRGO', 'Campago Resort Hotel (Superior Domestik) 1D', 3, 420000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Campago Resort Hotel terletak strategis di Ngawi; salah satu daerah lokal terkenal. Hotel ini tidak terlalu jauh dari pusat kota, hanya dari sini dan umumnya hanya membutuhkan waktu 90 menit untuk mencapai bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Campago Resort Hotel menjaminkan penginapan menyenangkan bagi para tamu. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati wi-fi di tempat-tempat umum, ruang merokok , concierge, layanan laundry, tur.</p>\r\n<p style=\"text-align: justify;\">Campago Resort Hotel memiliki 22 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti televisi, meja tulis, internet (wireless), AC, kulkas. Hotel ini menyediakan sejumlah fasilitas rekreasi seperti kolam (anak), taman, lapangan tenis, klub anak. Fasilitas super dan lokasi yang cemerlang menjadikan Campago Resort Hotel tempat yang sempurna untuk menikmati penginapan Anda selama di Ngawi.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Minimum umur tamu adalah: 1 tahun</li>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi dibawah 1 tahun</td>\r\n<td>Tidak diizinkan untuk menginap</td>\r\n</tr>\r\n<tr>\r\n<td>Bayi 1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Harus menggunakan ekstra bed</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat,layanan kamar, layanan kamar 24 jam, layanan laundry, restoran, ruang keluarga, ruang merokok, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>klub anak, kolam (anak), lapangan tenis, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(2, 'PGRGO', 'Campago Resort Hotel (Superior) 1D', 3, 460000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Campago Resort Hotel terletak strategis di Ngawi; salah satu daerah lokal terkenal. Hotel ini tidak terlalu jauh dari pusat kota, hanya dari sini dan umumnya hanya membutuhkan waktu 90 menit untuk mencapai bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Campago Resort Hotel menjaminkan penginapan menyenangkan bagi para tamu. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati wi-fi di tempat-tempat umum, ruang merokok , concierge, layanan laundry, tur.</p>\r\n<p style=\"text-align: justify;\">Campago Resort Hotel memiliki 22 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti televisi, meja tulis, internet (wireless), AC, kulkas. Hotel ini menyediakan sejumlah fasilitas rekreasi seperti kolam (anak), taman, lapangan tenis, klub anak. Fasilitas super dan lokasi yang cemerlang menjadikan Campago Resort Hotel tempat yang sempurna untuk menikmati penginapan Anda selama di Ngawi.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Minimum umur tamu adalah: 1 tahun</li>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi dibawah 1 tahun</td>\r\n<td>Tidak diizinkan untuk menginap</td>\r\n</tr>\r\n<tr>\r\n<td>Bayi 1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Harus menggunakan ekstra bed</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat,layanan kamar, layanan kamar 24 jam, layanan laundry, restoran, ruang keluarga, ruang merokok, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>klub anak, kolam (anak), lapangan tenis, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(3, 'PGRGO', 'Campago Resort Hotel (Family Suite) 1D', 3, 895000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Campago Resort Hotel terletak strategis di Ngawi; salah satu daerah lokal terkenal. Hotel ini tidak terlalu jauh dari pusat kota, hanya dari sini dan umumnya hanya membutuhkan waktu 90 menit untuk mencapai bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Campago Resort Hotel menjaminkan penginapan menyenangkan bagi para tamu. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati wi-fi di tempat-tempat umum, ruang merokok , concierge, layanan laundry, tur.</p>\r\n<p style=\"text-align: justify;\">Campago Resort Hotel memiliki 22 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti televisi, meja tulis, internet (wireless), AC, kulkas. Hotel ini menyediakan sejumlah fasilitas rekreasi seperti kolam (anak), taman, lapangan tenis, klub anak. Fasilitas super dan lokasi yang cemerlang menjadikan Campago Resort Hotel tempat yang sempurna untuk menikmati penginapan Anda selama di Ngawi.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Minimum umur tamu adalah: 1 tahun</li>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi dibawah 1 tahun</td>\r\n<td>Tidak diizinkan untuk menginap</td>\r\n</tr>\r\n<tr>\r\n<td>Bayi 1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Harus menggunakan ekstra bed</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat,layanan kamar, layanan kamar 24 jam, layanan laundry, restoran, ruang keluarga, ruang merokok, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>klub anak, kolam (anak), lapangan tenis, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(4, 'PGRGO', 'Campago Resort Hotel (Suite Keluarga) 1D', 3, 975000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Campago Resort Hotel terletak strategis di Ngawi; salah satu daerah lokal terkenal. Hotel ini tidak terlalu jauh dari pusat kota, hanya dari sini dan umumnya hanya membutuhkan waktu 90 menit untuk mencapai bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Campago Resort Hotel menjaminkan penginapan menyenangkan bagi para tamu. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati wi-fi di tempat-tempat umum, ruang merokok , concierge, layanan laundry, tur.</p>\r\n<p style=\"text-align: justify;\">Campago Resort Hotel memiliki 22 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti televisi, meja tulis, internet (wireless), AC, kulkas. Hotel ini menyediakan sejumlah fasilitas rekreasi seperti kolam (anak), taman, lapangan tenis, klub anak. Fasilitas super dan lokasi yang cemerlang menjadikan Campago Resort Hotel tempat yang sempurna untuk menikmati penginapan Anda selama di Ngawi.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Minimum umur tamu adalah: 1 tahun</li>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi dibawah 1 tahun</td>\r\n<td>Tidak diizinkan untuk menginap</td>\r\n</tr>\r\n<tr>\r\n<td>Bayi 1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Harus menggunakan ekstra bed</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat,layanan kamar, layanan kamar 24 jam, layanan laundry, restoran, ruang keluarga, ruang merokok, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>klub anak, kolam (anak), lapangan tenis, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(5, 'CRM', 'Hotel Benteng (Superior) 1D', 1, 290000, '<p style=\"text-align: justify;\">Jika apa yang Anda cari adalah hotel yang terletak strategis di Bukittinggi, carilah Hotel Benteng. Hanya 30. Km dari sini, hotel bintang 1 ini dapat secara mudah diakses dari bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Hotel Benteng juga menawari banyak fasilitas untuk memperkaya penginapan Anda di Ngawi. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati tur, wi-fi di tempat-tempat umum, layanan antar jemput, kotak penyimpanan aman, transfer bandara/hotel.</p>\r\n<p style=\"text-align: justify;\">Para tamu dapat memilih dari 37 kamar yang semuanya dilengkapi dengan atmosfir damai dan harmonis. Lagipula, beberapa persembahan rekreasi dari hotel ini akan menjamin Anda jauh dari kebosanan selama penginapan Anda. Apapun rencana kunjungan Anda, Hotel Benteng adalah pilihan bagus untuk penginapan di Ngawi.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 10 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-10 tahun</td>\r\n<td>Harus menggunakan ekstra bed</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, fasilitas rapat, kotak penyimpanan aman, layanan antar jemput, layanan kamar, layanan kamar 24 jam, layanan laundry, restoran, sewa sepeda, transfer bandara/hotel, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(6, 'CRM', 'Hotel Mitra Arena (Standar) 1D', 1, 185000, '<p style=\"text-align: justify;\">Ketika mengunjungi Ngawi, Anda akan merasa berada di rumah di Hotel Mitra Arena, dimana menawarkan akomodasi yang berkualitas dengan layanan luar biasa. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Di Hotel Mitra Arena, setiap usaha dilakukan untuk membuat tamu merasa nyaman. Dan untuk hal ini, hotel menyediakan yang terbaik untuk pelayanan dan perlengkapannya. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.</p>\r\n<p style=\"text-align: justify;\">Sebagai tambahan, semua kamar tamu memiliki sejumlah kenyamanan seperti AC, kulkas, shower, televisi, ruangan bebas rokok untuk menyenangi semakin banyak tamu. Baik Anda adalah orang yang senang fitness atau hanya ingin bersantai setelah beraktivitas sepanjang hari, Anda akan dihibur dengan fasilitas rekreasi kelas atas seperti taman. Ketika Anda mencari penginapan yang nyaman di Ngawi, jadikanlah Hotel Mitra Arena rumah Anda ketika Anda berlibur.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 12 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-2 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 3-12 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>restoran, ruang merokok</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>taman</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(7, 'CRM', 'Hotel Mitra Arena (Superior) 1D', 1, 230000, '<p style=\"text-align: justify;\">Ketika mengunjungi Ngawi, Anda akan merasa berada di rumah di Hotel Mitra Arena, dimana menawarkan akomodasi yang berkualitas dengan layanan luar biasa. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Di Hotel Mitra Arena, setiap usaha dilakukan untuk membuat tamu merasa nyaman. Dan untuk hal ini, hotel menyediakan yang terbaik untuk pelayanan dan perlengkapannya. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.</p>\r\n<p style=\"text-align: justify;\">Sebagai tambahan, semua kamar tamu memiliki sejumlah kenyamanan seperti AC, kulkas, shower, televisi, ruangan bebas rokok untuk menyenangi semakin banyak tamu. Baik Anda adalah orang yang senang fitness atau hanya ingin bersantai setelah beraktivitas sepanjang hari, Anda akan dihibur dengan fasilitas rekreasi kelas atas seperti taman. Ketika Anda mencari penginapan yang nyaman di Ngawi, jadikanlah Hotel Mitra Arena rumah Anda ketika Anda berlibur.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 12 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-2 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 3-12 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>restoran, ruang merokok</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>taman</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(8, 'PGDRN', 'Royal Denai View Hotel (Superior) 1D', 2, 365000, '<p style=\"text-align: justify;\">Menawarkan akomodasi berkualitas di kebudayaan, berbelanja, melihat-lihat distrik Ngawi, Royal Denai View Hotel adalah pilihan populer bagi para wisatawan plesir dan bisnis. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Dengan menawarkan pelayanan superior dan sejumlah fasilitas kepada para tamu hotel, Royal Denai View Hotel berkomitmen untuk menjaga kenyamanan penginapan Anda semaksimal mungkin. Kotak penyimpanan aman, tempat parkir mobil, wi-fi di tempat-tempat umum, layanan laundry, pusat bisnis hanyalah beberapa fasilitas yang membedakan Royal Denai View Hotel dari hotel-hotel lain di kota ini.</p>\r\n<p style=\"text-align: justify;\">Suasana Royal Denai View Hotel tercerminkan dari setiap kamar tamu. televisi, mini bar, televisi LCD/layar plasma, AC, ruangan bebas rokok hanyalah beberapa fasilitas yang dapat Anda gunakan. Sepanjang hari Anda dapat menikmati atmosfir santai dari taman. Nikmati pelayanan cemerlang dan alamat yang benar-benar mewah di Royal Denai View Hotel.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 10 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n<li>Untuk para pasangan, mohon dicatat bahwa sangatlah wajib untuk menunjukkan surat nikah (buku nikah) pada saat check-in.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 3-10 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, pusat bisnis, restoran, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(9, 'PGDRN', 'Royal Denai View Hotel (Delux) 1D', 2, 520000, '<p style=\"text-align: justify;\">Menawarkan akomodasi berkualitas di kebudayaan, berbelanja, melihat-lihat distrik Ngawi, Royal Denai View Hotel adalah pilihan populer bagi para wisatawan plesir dan bisnis. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Dengan menawarkan pelayanan superior dan sejumlah fasilitas kepada para tamu hotel, Royal Denai View Hotel berkomitmen untuk menjaga kenyamanan penginapan Anda semaksimal mungkin. Kotak penyimpanan aman, tempat parkir mobil, wi-fi di tempat-tempat umum, layanan laundry, pusat bisnis hanyalah beberapa fasilitas yang membedakan Royal Denai View Hotel dari hotel-hotel lain di kota ini.</p>\r\n<p style=\"text-align: justify;\">Suasana Royal Denai View Hotel tercerminkan dari setiap kamar tamu. televisi, mini bar, televisi LCD/layar plasma, AC, ruangan bebas rokok hanyalah beberapa fasilitas yang dapat Anda gunakan. Sepanjang hari Anda dapat menikmati atmosfir santai dari taman. Nikmati pelayanan cemerlang dan alamat yang benar-benar mewah di Royal Denai View Hotel.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 10 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n<li>Untuk para pasangan, mohon dicatat bahwa sangatlah wajib untuk menunjukkan surat nikah (buku nikah) pada saat check-in.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 3-10 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, pusat bisnis, restoran, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(10, 'PSRPTH', 'Pusako Hotel (Standar) 1D', 4, 498000, '<p style=\"text-align: justify;\">Terletak secara nyaman di melihat-lihat, berbelanja, kebudayaan area kota Ngawi, Pusako Hotel menyediakan tempat yang kondusif untuk liburan Anda selama beberapa hari. Hanya 75 km dari sini, hotel bintang 4 ini dapat secara mudah diakses dari bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Gunakan kesempatan untuk menikmati pelayanan dan fasilitas yang tak tertandingkan di hotel Bukittinggi ini. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati coffee shop, toko, restoran, layanan kamar, wi-fi di tempat-tempat umum.</p>\r\n<p style=\"text-align: justify;\">Pusako Hotel memiliki 140 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti mini bar, kulkas, internet (wireless), pembuat kopi/teh, shower. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti gym/fasilitas kebugaran, kolam renang (luar ruangan), lapangan tenis untuk menjadikan penginapan Anda tak terlupakan. Dengan lokasi ideal dan fasilitas yang setara, Pusako Hotel dapat memenuhinya semua.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, coffee shop, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, pusat bisnis, toko, restoran, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>gym/fasilitas kebugaran, kolam renang (luar ruangan), lapangan tenis</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(11, 'PSRPTH', 'Pusako Hotel (Delux) 1D', 4, 548000, '<p style=\"text-align: justify;\">Terletak secara nyaman di melihat-lihat, berbelanja, kebudayaan area kota Ngawi, Pusako Hotel menyediakan tempat yang kondusif untuk liburan Anda selama beberapa hari. Hanya 75 km dari sini, hotel bintang 4 ini dapat secara mudah diakses dari bandara. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Gunakan kesempatan untuk menikmati pelayanan dan fasilitas yang tak tertandingkan di hotel Bukittinggi ini. Ketika menginap di properti yang luar biasa ini, para tamu dapat menikmati coffee shop, toko, restoran, layanan kamar, wi-fi di tempat-tempat umum.</p>\r\n<p style=\"text-align: justify;\">Pusako Hotel memiliki 140 kamar tidur yang semuanya dirancang dengan citarasa tinggi untuk menyediakan kenyamanan seperti mini bar, kulkas, internet (wireless), pembuat kopi/teh, shower. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti gym/fasilitas kebugaran, kolam renang (luar ruangan), lapangan tenis untuk menjadikan penginapan Anda tak terlupakan. Dengan lokasi ideal dan fasilitas yang setara, Pusako Hotel dapat memenuhinya semua.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 7 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-7 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, coffee shop, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, pusat bisnis, toko, restoran, wi-fi di tempat-tempat umum, Wi-Fi gratis di semua kamar</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>gym/fasilitas kebugaran, kolam renang (luar ruangan), lapangan tenis</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(12, 'CMJ', 'Hotel Pagaruyung Dua (Standar Domestik) 1D', 1, 395000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Hotel Pagaruyung Dua terletak strategis di Surabaya; salah satu daerah lokal terkenal. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Hotel Pagaruyung Dua juga menawari banyak fasilitas untuk memperkaya penginapan Anda di Surabaya. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.</p>\r\n<p style=\"text-align: justify;\">Masuki salah satu dari 40 kamar yang mengundang ini dan lepaskan tekanan dan kelelahan sepanjang hari dengan sejumlah fasilitas yang tersedia seperti AC, ruang duduk. Fasilitas rekreasi hotel ini seperti gym/fasilitas kebugaran, taman dirancang untuk berelaksasi. Hotel Pagaruyung Dua adalah destinasi paling tepat Anda untuk akomodasi hotel berkualitas di Surabaya.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-12 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>fasilitas rapat, layanan laundry, restoran, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>gym/fasilitas kebugaran, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(13, 'CMJ', 'Hotel Pagaruyung Dua (Standar) 1D', 1, 415000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Hotel Pagaruyung Dua terletak strategis di Surabaya; salah satu daerah lokal terkenal. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Hotel Pagaruyung Dua juga menawari banyak fasilitas untuk memperkaya penginapan Anda di Surabaya. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.</p>\r\n<p style=\"text-align: justify;\">Masuki salah satu dari 40 kamar yang mengundang ini dan lepaskan tekanan dan kelelahan sepanjang hari dengan sejumlah fasilitas yang tersedia seperti AC, ruang duduk. Fasilitas rekreasi hotel ini seperti gym/fasilitas kebugaran, taman dirancang untuk berelaksasi. Hotel Pagaruyung Dua adalah destinasi paling tepat Anda untuk akomodasi hotel berkualitas di Surabaya.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-12 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>fasilitas rapat, layanan laundry, restoran, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>gym/fasilitas kebugaran, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(14, 'CMJ', 'Mercure Hotel (Superior) 1D', 4, 620000, '<p style=\"text-align: justify;\">Terletak strategis di Malang, Mercure Malang Hotel adalah tempat yang cocok untuk menelusuri kota yang hidup ini. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Yang tidak ketinggalan adalah akses mudah dari hotel ini ke sejumlah atraksi dan markah tanah kota ini seperti Stadion Haji Agus Salim, Museum Adityawarman, Jalan Kuliner Simpang Kinol.</p>\r\n<p style=\"text-align: justify;\">Accor Hotels terkenal untuk pelayanan berkualitas dan staf yang ramah, dan Mercure Malang Hotel memenuhi ekspektasi tersebut. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.</p>\r\n<p style=\"text-align: justify;\">Sebagai tambahan, semua kamar tamu memiliki sejumlah kenyamanan seperti AC, TV satelit/kabel, ruang duduk, meja tulis, ruangan bebas rokok untuk menyenangi semakin banyak tamu. Hotel ini menawarkan fasilitas rekreasi fantastis termasuk gym/fasilitas kebugaran, pijat, lapangan tenis, taman, lapangan golf (dalam 3 km) , untuk membantu Anda berelaksasi setelah sepanjang hari beraktivitas di kota. Mercure Malang Hotel adalah tempat penginapan ideal bagi para pelancong yang mencari daya tarik, kenyamanan dan kepraktisan di Malang.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 15 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi.</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-15 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, bar tepi-kolam, concierge,fasilitas bagi tamu dengan kebutuhan khusus, fasilitas rapat, layanan antar jemput, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, penitipan bayi, restoran, ruang merokok, toko, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>gym/fasilitas kebugaran, klub anak, kolam renang (luar ruangan), lapangan golf (dalam 3 km), lapangan tenis, pijat, sauna, spa, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(15, 'PSRPTH', 'Daima Hotel (Superior Domestik) 1D', 3, 395000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Daima Hotel Malang terletak strategis di Malang Barat; salah satu daerah lokal terkenal. Hanya 20.00 Km dari sini, hotel bintang 3 ini dapat secara mudah diakses dari bandara. Lingkungan yang dijaga serta kedekatan ke Museum Adityawarman, Stadion Haji Agus Salim, Jalan Kuliner Simpang Kinol sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Daima Hotel Malang menjaminkan penginapan menyenangkan bagi para tamu. Sejumlah pilihan fasilitas kelas atas seperti pusat bisnis, ruang merokok , concierge, layanan laundry, ruang keluarga dapat dinikmati di hotel ini.</p>\r\n<p style=\"text-align: justify;\">Hotel ini memiliki 93 kamar tamu yang indah, masing-masing termasuk televisi LCD/layar plasma, internet (gratis), kulkas, koran harian, AC. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti pijat untuk menjadikan penginapan Anda tak terlupakan. Apapun rencana kunjungan Anda, Daima Hotel Malang adalah pilihan bagus untuk penginapan di Malang.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-6 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, lantai eksekutif, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, pusat bisnis, restoran, ruang keluarga, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(16, 'PSRPTH', 'Daima Hotel  (Superior) 1D', 3, 415000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Daima Hotel Malang terletak strategis di Malang Barat; salah satu daerah lokal terkenal. Hanya 20.00 Km dari sini, hotel bintang 3 ini dapat secara mudah diakses dari bandara. Lingkungan yang dijaga serta kedekatan ke Museum Adityawarman, Stadion Haji Agus Salim, Jalan Kuliner Simpang Kinol sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Daima Hotel Malang menjaminkan penginapan menyenangkan bagi para tamu. Sejumlah pilihan fasilitas kelas atas seperti pusat bisnis, ruang merokok , concierge, layanan laundry, ruang keluarga dapat dinikmati di hotel ini.</p>\r\n<p style=\"text-align: justify;\">Hotel ini memiliki 93 kamar tamu yang indah, masing-masing termasuk televisi LCD/layar plasma, internet (gratis), kulkas, koran harian, AC. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti pijat untuk menjadikan penginapan Anda tak terlupakan. Apapun rencana kunjungan Anda, Daima Hotel Malang adalah pilihan bagus untuk penginapan di Malang.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-6 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, lantai eksekutif, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, pusat bisnis, restoran, ruang keluarga, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(17, 'PRH', 'Daima Hotel (Delux Domestik) 1D', 3, 432000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Daima Hotel Malang terletak strategis di Malang Barat; salah satu daerah lokal terkenal. Hanya 20.00 Km dari sini, hotel bintang 3 ini dapat secara mudah diakses dari bandara. Lingkungan yang dijaga serta kedekatan ke Museum Adityawarman, Stadion Haji Agus Salim, Jalan Kuliner Simpang Kinol sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Daima Hotel Malang menjaminkan penginapan menyenangkan bagi para tamu. Sejumlah pilihan fasilitas kelas atas seperti pusat bisnis, ruang merokok , concierge, layanan laundry, ruang keluarga dapat dinikmati di hotel ini.</p>\r\n<p style=\"text-align: justify;\">Hotel ini memiliki 93 kamar tamu yang indah, masing-masing termasuk televisi LCD/layar plasma, internet (gratis), kulkas, koran harian, AC. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti pijat untuk menjadikan penginapan Anda tak terlupakan. Apapun rencana kunjungan Anda, Daima Hotel Malang adalah pilihan bagus untuk penginapan di Malang.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-6 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, lantai eksekutif, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, pusat bisnis, restoran, ruang keluarga, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(18, 'PRH', 'Daima Hotel (Delux) 1D', 3, 455000, '<p style=\"text-align: justify;\">Dirancang untuk wisata plesir dan bisnis, Daima Hotel Malang terletak strategis di Malang Barat; salah satu daerah lokal terkenal. Hanya 20.00 Km dari sini, hotel bintang 3 ini dapat secara mudah diakses dari bandara. Lingkungan yang dijaga serta kedekatan ke Museum Adityawarman, Stadion Haji Agus Salim, Jalan Kuliner Simpang Kinol sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Fasilitas dan pelayanan yang ditawarkan Daima Hotel Malang menjaminkan penginapan menyenangkan bagi para tamu. Sejumlah pilihan fasilitas kelas atas seperti pusat bisnis, ruang merokok , concierge, layanan laundry, ruang keluarga dapat dinikmati di hotel ini.</p>\r\n<p style=\"text-align: justify;\">Hotel ini memiliki 93 kamar tamu yang indah, masing-masing termasuk televisi LCD/layar plasma, internet (gratis), kulkas, koran harian, AC. Hotel ini menawarkan fasilitas rekreasi yang menyenangkan seperti pijat untuk menjadikan penginapan Anda tak terlupakan. Apapun rencana kunjungan Anda, Daima Hotel Malang adalah pilihan bagus untuk penginapan di Malang.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Anak-anak 0-6 tahun</td>\r\n<td>Menginap gratis jika menggunakan ranjang yang tersedia.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, lantai eksekutif, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, pusat bisnis, restoran, ruang keluarga, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(19, 'PRH', 'Grand Zuri Hotel (Superior) 1D', 4, 476000, '<p style=\"text-align: justify;\">Terletak strategis di Malang, Grand Zuri Malang Hotel adalah tempat yang cocok untuk menelusuri kota yang hidup ini. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Lingkungan yang dijaga serta kedekatan ke Jalan Kuliner Simpang Kinol, Museum Adityawarman, Jembatan Siti Nurbaya sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Di Grand Zuri Malang Hotel, pelayanan cemerlang dan fasilitas yang bagus akan membuat penginapan Anda tak terlupakan. Untuk kenyamanan para tamu, hotel ini menawarkan transfer bandara/hotel, concierge, kotak penyimpanan aman, wi-fi di tempat-tempat umum, layanan kamar 24 jam.</p>\r\n<p style=\"text-align: justify;\">Sebagai tambahan, semua kamar tamu memiliki sejumlah kenyamanan seperti kulkas, meja tulis, air botol gratis, televisi, AC untuk menyenangi semakin banyak tamu. Pijat, taman, sauna hotel ini adalah tempat-tempat ideal untuk bersantai setelah hari yang sibuk. Dengan lokasi ideal dan fasilitas yang setara, Grand Zuri Malang Hotel dapat memenuhinya semua.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 3 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi.</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-3 tahun</td>\r\n<td>Harus menggunakan ekstra bed.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, restoran, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat, sauna, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(20, 'PRH', 'Grand Zuri Hotel (Delux) 1D', 4, 587000, '<p style=\"text-align: justify;\">Terletak strategis di Malang, Grand Zuri Malang Hotel adalah tempat yang cocok untuk menelusuri kota yang hidup ini. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Lingkungan yang dijaga serta kedekatan ke Jalan Kuliner Simpang Kinol, Museum Adityawarman, Jembatan Siti Nurbaya sangat memberikan nilai tambah untuk hotel ini.</p>\r\n<p style=\"text-align: justify;\">Di Grand Zuri Malang Hotel, pelayanan cemerlang dan fasilitas yang bagus akan membuat penginapan Anda tak terlupakan. Untuk kenyamanan para tamu, hotel ini menawarkan transfer bandara/hotel, concierge, kotak penyimpanan aman, wi-fi di tempat-tempat umum, layanan kamar 24 jam.</p>\r\n<p style=\"text-align: justify;\">Sebagai tambahan, semua kamar tamu memiliki sejumlah kenyamanan seperti kulkas, meja tulis, air botol gratis, televisi, AC untuk menyenangi semakin banyak tamu. Pijat, taman, sauna hotel ini adalah tempat-tempat ideal untuk bersantai setelah hari yang sibuk. Dengan lokasi ideal dan fasilitas yang setara, Grand Zuri Malang Hotel dapat memenuhinya semua.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 3 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi.</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-3 tahun</td>\r\n<td>Harus menggunakan ekstra bed.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, restoran, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat, sauna, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(21, 'CRM', 'Savali Hotel (Superior) 1D', 3, 501000, '	<p style=\"text-align: justify;\">Dibangun pada 2010, Savali Hotel adalah pelengkap yang berbeda di Malang dan pilihan yang cerdas bagi wisatawan. Dari sini, para tamu dapat menikmati akses mudah ke semua hal yang dapat ditemukan di sebuah kota yang hidup. Dengan lokasinya yang strategis, hotel ini menawarkan akses mudah ke destinasi yang wajib dilihat di kota ini.</p>\r\n<p style=\"text-align: justify;\">Dengan menawarkan pelayanan superior dan sejumlah fasilitas kepada para tamu hotel, Savali Hotel berkomitmen untuk menjaga kenyamanan penginapan Anda semaksimal mungkin. Fasilitas top hotel ini termasuk toko, sewa sepeda, layanan laundry, coffee shop, fasilitas rapat.</p>\r\n<p style=\"text-align: justify;\">Semua akomodasi tamu dilengkapi dengan fasilitas yang telah dirancang dengan baik demi menjaga kenyamanan. Baik Anda adalah orang yang senang fitness atau hanya ingin bersantai setelah beraktivitas sepanjang hari, Anda akan dihibur dengan fasilitas rekreasi kelas atas seperti kolam renang (luar ruangan), taman, pijat. Savali Hotel adalah pilihan yang cerdas bagi para pelancong ke Malang, dengan menawarkan penginapan yang santai setiap saat.</p>\r\n<h3>Kebijakan Hotel</h3>\r\n<ul>\r\n<li>Tamu berumur diatas 3 tahun dianggap sebagai tamu dewasa.</li>\r\n<li>Ekstra bed tergantung pada kamar yang Anda pilih, silahkan cek kebijakan setiap kamar untuk detil lebih lanjut.</li>\r\n</ul>\r\n<table style=\"margin-left: auto; margin-right: auto;\">\r\n<tbody>\r\n<tr>\r\n<td>Bayi 0-1 tahun</td>\r\n<td>Menginap gratis dengan menggunakan tempat tidur yang tersedia. Catatan, biaya tambahan kemungkinan dikenakan jika Anda membutuhkan ranjang bayi.</td>\r\n</tr>\r\n<tr>\r\n<td>Anak-anak 2-3 tahun</td>\r\n<td>Harus menggunakan ekstra bed.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h3>Fasilitas Hotel</h3>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Fasilitas</td>\r\n<td>bar, coffee shop, concierge, fasilitas rapat, kotak penyimpanan aman, layanan kamar, layanan kamar 24 jam, layanan laundry, lift, restoran, ruang merokok, transfer bandara/hotel, wi-fi di tempat-tempat umum</td>\r\n</tr>\r\n<tr>\r\n<td>Olahraga dan Rekreasi</td>\r\n<td>pijat, sauna, taman</td>\r\n</tr>\r\n<tr>\r\n<td>Internet dalam Kamar</td>\r\n<td>Akses WiFi gratis</td>\r\n</tr>\r\n<tr>\r\n<td>Parkir</td>\r\n<td>tempat parkir mobil, parkir valet</td>\r\n</tr>\r\n</tbody>\r\n</table>'),
(22, 'CRM', 'Didn\'t stay overnight', 1, 0, '<p>For one way trip</p>'),
(23, 'CMJ', 'Didn\'t stay overnight', 1, 0, '<p>For one way trip</p>'),
(24, 'PGRGO', 'Didn\'t stay overnight', 1, 0, '<p>For one way trip</p>'),
(25, 'PSRPTH', 'Didn\'t stay overnight', 1, 0, '<p>For one way trip</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id_kategori`, `kategori`, `keterangan`) VALUES
(1, 'Individual Package', 'This Travel Package is specially designed for tourists who want to take a vacation alone. But later in the Tour, Tourists will depart together in one car. In one car, a maximum of only 4 tourists, included with the driver and tour guide.'),
(2, 'Group Package', 'kedua kalinya'),
(3, 'Family Package', 'ketiga kalinya'),
(4, 'Couple Package', 'Recommended for honey moon or trip with tour couple.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paket`
--

CREATE TABLE `tbl_paket` (
  `id_paket` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_paket` varchar(50) NOT NULL,
  `harga_paket` int(11) NOT NULL,
  `ket_paket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_paket`
--

INSERT INTO `tbl_paket` (`id_paket`, `id_kategori`, `nama_paket`, `harga_paket`, `ket_paket`) VALUES
(1, 1, 'One-Way Trip', 150000, 'This package is for individual tours. The tour will be synchronized with other tourists who also choose the same package. The number of people in the group is about 3-5 people.'),
(2, 1, '2 Day Trip', 250000, 'This package is for individual tours. The tour will be synchronized with other tourists who also choose the same package. The number of people in the group is about 3-5 people.'),
(3, 1, 'Tanjung Lesung 3 Day', 400000, 'This package is for individual tours. The tour will be synchronized with other tourists who also choose the same package. The number of people in the group is about 3-5 people.'),
(4, 4, 'Promo Pangrango 7 Day Couple', 700000, 'This promo package is for a tour in Pangrango Mountain for 7 days. For lodging we recommend around the Bromo area itself.'),
(5, 4, 'Cimaja Beach One-Way Couple', 225000, 'This package is for a couple tour. This package is for one trip only or is intended for those who want to travel but do not stay overnight.'),
(6, 4, 'Pangandaran Mountain 2 Day Couple', 325000, 'This package is for a couple tour. This package is for 2 Daystrip only or is intended.'),
(7, 2, '7 Day Trip With Family', 80000000, '<p>Recommended for family vacation with best views in West Java\r\n</p>'),
(8, 3, 'Group Package', 5000000, '<p>Bring all your friend to enjoy the views of West Java</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pesan`
--

CREATE TABLE `tbl_pesan` (
  `id_pesan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `tgl_tour` date NOT NULL,
  `status` char(2) NOT NULL DEFAULT 'S1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_pesan`
--

INSERT INTO `tbl_pesan` (`id_pesan`, `id_user`, `id_paket`, `id_hotel`, `tgl_pesan`, `tgl_tour`, `status`) VALUES
(1, 11, 1, 1, '2017-07-07', '2017-07-24', 'S1'),
(2, 13, 6, 4, '2017-07-13', '2017-07-25', 'S1'),
(3, 14, 1, 12, '2020-02-24', '2020-02-29', 'S3'),
(4, 15, 2, 0, '2020-11-17', '2020-11-17', 'S1'),
(5, 15, 6, 19, '2020-11-19', '2020-11-27', 'S2'),
(6, 15, 0, 13, '2020-11-19', '2020-11-17', 'S3'),
(7, 15, 1, 25, '2020-12-01', '2020-12-19', 'S2'),
(8, 15, 1, 5, '2020-12-02', '2020-12-02', 'S3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `email_user` varchar(50) NOT NULL,
  `tipe_id` varchar(20) NOT NULL,
  `no_id` varchar(30) NOT NULL,
  `no_hp` varchar(14) NOT NULL,
  `no_rek` varchar(50) NOT NULL,
  `nama_rek` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL,
  `tgl_lahir` varchar(30) NOT NULL,
  `jekel` varchar(1) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `email_user`, `tipe_id`, `no_id`, `no_hp`, `no_rek`, `nama_rek`, `username`, `password`, `tgl_lahir`, `jekel`, `alamat`) VALUES
(15, 'Dhaffa Abdillah Hakim', 'test@gmail.com', 'SIM', 'eyru5u6u67i6', '088210837569', '24353443', '454645764', 'dhaffa', 'dhaffa', '17 Nov 2020', 'L', '<p>fhdgnvmbjhf</p>'),
(16, 'dddd', 'ddd@ddd.com', 'Visa Card', 'eyru5u6u67i6', '', 'tr7rtryry', 'dedeferghjcv', 'ddd', 'ddd', '28 Nov 2020', 'L', '<p>qenflnfqfef<strong>efwfwefef<em>wfwfwfwefwfwfwf</em></strong></p>'),
(17, 'Username', 'username@gmail.com', '', '', '', '', '', 'user', 'user', '', 'L', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`id_komentar`);

--
-- Indexes for table `setup_about`
--
ALTER TABLE `setup_about`
  ADD PRIMARY KEY (`id_about`);

--
-- Indexes for table `setup_dasboard`
--
ALTER TABLE `setup_dasboard`
  ADD PRIMARY KEY (`id_dasboard`);

--
-- Indexes for table `setup_slide`
--
ALTER TABLE `setup_slide`
  ADD PRIMARY KEY (`id_slide`);

--
-- Indexes for table `setup_sumbar`
--
ALTER TABLE `setup_sumbar`
  ADD PRIMARY KEY (`id_sumbar`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`user_admin`);

--
-- Indexes for table `tbl_bukti`
--
ALTER TABLE `tbl_bukti`
  ADD PRIMARY KEY (`id_bukti`);

--
-- Indexes for table `tbl_daerah`
--
ALTER TABLE `tbl_daerah`
  ADD PRIMARY KEY (`id_daerah`);

--
-- Indexes for table `tbl_hotel`
--
ALTER TABLE `tbl_hotel`
  ADD PRIMARY KEY (`id_hotel`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`id_kategori`),
  ADD KEY `id_kat` (`id_kategori`);

--
-- Indexes for table `tbl_paket`
--
ALTER TABLE `tbl_paket`
  ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
  MODIFY `id_komentar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `setup_about`
--
ALTER TABLE `setup_about`
  MODIFY `id_about` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `setup_dasboard`
--
ALTER TABLE `setup_dasboard`
  MODIFY `id_dasboard` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `setup_slide`
--
ALTER TABLE `setup_slide`
  MODIFY `id_slide` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `setup_sumbar`
--
ALTER TABLE `setup_sumbar`
  MODIFY `id_sumbar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tbl_bukti`
--
ALTER TABLE `tbl_bukti`
  MODIFY `id_bukti` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_daerah`
--
ALTER TABLE `tbl_daerah`
  MODIFY `id_daerah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_hotel`
--
ALTER TABLE `tbl_hotel`
  MODIFY `id_hotel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_paket`
--
ALTER TABLE `tbl_paket`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
