<nav class="navigation-bar dark">
        <nav class="navigation-bar-content container">
        	<a href="index.html" class="element"><span class="icon-home"></span> Home</a>
            <span class="element-divider"></span>
                
			<a class="element1 pull-menu" href="#"></a>
			<ul class="element-menu">
				<li>
					<a class="dropdown-toggle" href="#">Reservation & More</a>
					<ul class="dropdown-menu" data-role="dropdown">
						<li><a href="aboutUs.php?post=profil">Profile</a></li>
						<li><a href="listPaket.php">Package List</a></li>
						<li><a href="listPenginapan.php">Lodging List</a></li>
						<li class="divider"></li>
						<li><a href="aboutUs.php?post=syarat">Prerequisite &amp; Provisions</a></li>
						<li><a href="aboutUs.php?post=reservasi">How to reserve</a></li>
						<li><a href="aboutUs.php?post=pembayaran">Payment Method</a></li>
					</ul>  
				</li>
				<li>
					<a class="dropdown-toggle" href="#">About West Java</a>
					<ul class="dropdown-menu" data-role="dropdown">
						<li><a href="sumbar.php?post=profil">Profile</a></li>
						<li><a href="sumbar.php?post=sejarah">History</a></li>
						<li><a href="galeri.php">Gallery</a></li>
						<li class="divider"></li>
						<li><a href="sumbar.php?post=wisata">Tourist Attraction</a></li>
						<li><a href="sumbar.php?post=kuliner">Culinary Variant</a></li>
						<li><a href="sumbar.php?post=budaya">Culture</a></li>
					</ul>
				</li>
				
				<a class="element brand" href="contact.php">Contact</a>
				<!-- -------------------------MENU KANAN---------------------------- -->
					 
				<a class="element place-right" href="https://twitter.com/dhaffaabdillah">
						<span class="icon-twitter" style="background: white;
						   color: black;
						   padding: 3px;
						   border-radius: 50%">
						</span>
				</a>
				<a class="element place-right" href="https://instagram.com/e.ky_">
						<span class="icon-instagram" style="background: white;
						   color: black;
						   padding: 3px;
						   border-radius: 50%">
						</span>
				</a>
								
	<?php session_start();

	if(isset($_SESSION['username'])){
	?>
				<span class="element-divider place-right"></span>
				<div class="element place-right">                   
					<a class="dropdown-toggle icon-cog" href="#"></a>
					<ul class="dropdown-menu" data-role="dropdown">
						<li><a href="profil.php">Profile</a></li>
						<li><a href="booking.php">Booking</a></li>
						<li><a href="bookingList.php">Check Booking</a></li>
						<li class="divider"></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
				<a href="profil.php" class="element place-right">Welcome, <?php echo "$_SESSION[username]"; ?></a>
				
	<?php
	}else{
	?>
				<span class="element-divider"></span>
				<a href="formRegistrasi.php" class="element">Login</a>
	<?php
	}
	?>
				
            </ul>
        </nav>
    </nav>

<?php
include"chat.php";
?>
