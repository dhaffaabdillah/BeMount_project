<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="css/metro-bootstrap.css" rel="stylesheet">
    <link href="css/metro-bootstrap-responsive.css" rel="stylesheet">
    <link href="css/iconFont.css" rel="stylesheet">
    <link href="css/docs.css" rel="stylesheet">


    <!-- Load JavaScript Libraries -->
    <script src="js/jquery/jquery.min.js"></script>
    <script src="js/jquery/jquery.widget.min.js"></script>
    <script src="js/jquery/jquery.mousewheel.js"></script>

    <!-- Metro UI CSS JavaScript plugins -->
    <script src="js/load-metro.js"></script>
    <script src="js/docs.js"></script>
    
    <style>
    </style>

<title>Login</title>
</head>

<?php  session_start();

include "config/koneksi.php";

if (isset($_POST['Login'])){
	//koneksi terpusat

	$username=$_POST['username'];
	$password=$_POST['password'];
	
		$query=mysql_query("select * from tbl_user where username='$username' and password='$password'");
		$cek=mysql_num_rows($query);
		$row=mysql_fetch_array($query);
		
		if($cek){
			$_SESSION['username']=$username;
			$_SESSION['password']=$password;
			
			?><script language="javascript">document.location.href="profil.php";</script><?php
			
		}else{
			?><script language="javascript">document.location.href="formRegistrasi.php?status=Login Failed";</script><?php
		}		
		

}else{
	unset($_POST['Login']);
}

if (isset($_POST['Register'])){
	//koneksi terpusat
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(empty($username)){
?>
<script>
	$(function(){
		setTimeout(function(){
			$.Notify({
				style: {background: 'red', color: 'white'}, 
				content: "Username can't be empty"
			}, 1000);
		});
	});
</script>
<?php
	}if(empty($password)){
?>
<script>
	$(function(){
		setTimeout(function(){
			$.Notify({
				style: {background: 'green', color: 'white'}, 
				content: "Password can't be empty!"
			}, 2000);
		});
	});
</script>
<?php
	}else{
		$query = mysql_query("insert into tbl_user (nama_user, email_user, username, password, jekel)
		value ('$_POST[nama]','$_POST[email]','$_POST[username]','$_POST[password]','$_POST[jekel]')");
	
		if($query){
			header("location:formRegistrasi.php?status=Success register");
		
		}else{
				?><script language="javascript">document.location.href="formRegistrasi.php?status=Failed to register";</script><?php
		}		
	}

}

?>

<body class="metro">
	<header class="bg-darkCobalt" data-load="atasan.php"></header>
    
    <div class="" data-load="slider.php"></div>
    <br />
    <!-- ---------------------------------------- ISI TAB ------------------------------------- -->
    <div class="container">
        <div class="grid">
        	<div class="accordion" data-role="accordion" data-closeany="true">
                <div class="accordion-frame">
                    <a class="active heading bg-darkCobalt fg-white" href="#" >Login</a>
                    <div class="content">
                        <div class="grid">
                            <div class="row">
								<div class="span7">
                                <div class="carousel " id="imgSlide">
                                    <div class="slide">
                                        <img src="images/GUNUNG/Gunung_Salak.jpg" class="cover1" />
                                    </div>

                                    <div class="slide">
                                        <img src="images/PANTAI/Pantai-BatuKaras.jpg" class="cover1" />
                                    </div>

                                    <div class="slide">
                                        <img src="images/GUNUNG/Gunung-Pangrango.jpg" class="cover1"/>
                                    </div>
									
									<div class="slide">
                                        <img src="images/PANTAI/Pantai-PulauPeucang.jpg" class="cover1" />
                                    </div>
                                </div>
                                <script>
                                    $(function(){
                                        $("#imgSlide").carousel({
                                            effect: 'slide',
											period: 3000,
                                            markers: {
                                                show: false,
                                                type: 'default',
                                                position: 'bottom-right'
                                            }
                                        });
                                    })
                                </script>
								</div>
                                
                                <div class="span5 offset2">
                                    <form name="formLogin" method="post" action="formRegistrasi.php">
                                        <fieldset>
                                        	<h5><?php  if(isset($_GET['status'])){ echo "&laquo; ".$_GET['status']." &raquo;"; }?></h5>
                                            <legend>Login</legend>
                                            <div class="input-control text" data-role="input-control">
                                                <input type="text" name="username" required="required" placeholder="Username:" autofocus>
                                                <button class="btn-clear" tabindex="-1"></button>
                                            </div>
                                            <div class="input-control password" data-role="input-control">
                                                <input type="password" name="password" required="required" placeholder="Password:">
                                                <button class="btn-reveal" tabindex="-1"></button>
                                            </div>
                                            
                                            <input type="submit" name="Login" id="Login" value="Sign in">
                                            <input type="reset" value="Cancel">
                                        </fieldset>
                                    </form>
                                </div>
                                
                            </div>
							<br/>
							<div class="balloon top">
								<div class="padding5">
									Click <b>register</b> if you doesn't have an account.
								</div>
							</div>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-frame">
                    <a class="heading bg-darkRed fg-white" href="#">Sign Up</a>
                    <div class="content">
                        <div class="grid">
                            <div class="row">
                                
                                <div class="span6">
                                    <form name="formRegister" method="post" action="formRegistrasi.php">
                                        <fieldset>
                                        	<h5><?php  if(isset($_GET['status'])){ echo "&laquo; ".$_GET['status']." &raquo;"; }?></h5>
                                            <legend>Register here</legend>
                                            <lable>Complete Name</lable>
                                            <div class="input-control text" data-role="input-control">
                                                <input type="text" name="nama" placeholder="Input your complete name!">
                                                <button class="btn-clear" tabindex="-1"></button>
                                            </div>
                                            <lable>Email</lable>
                                            <div class="input-control text" data-role="input-control">
                                                <input type="email" name="email" required="required" placeholder="example@gmail.com">
                                                <button class="btn-clear" tabindex="-1"></button>
                                            </div>
                                            <lable>Username</lable>
                                            <div class="input-control text" data-role="input-control">
                                                <input type="text" name="username" placeholder="Input your username">
                                                <button class="btn-clear" tabindex="-1"></button>
                                            </div>
                                            <lable>Password</lable>
                                            <div class="input-control password" data-role="input-control">
                                                <input type="password" name="password" placeholder="Input Password" autofocus>
                                                <button class="btn-reveal" tabindex="-1"></button>
                                            </div>
                                            <lable>Gender</lable>
                                            <div>
                                                <div class="input-control radio" data-role="input-control">
                                                    <label>
                                                        <input type="radio" name="jekel" value="L" />
                                                        <span class="check"></span>
                                                        Male
                                                    </label>
                                                </div>
                                                <div class="input-control radio" data-role="input-control">
                                                    <label>
                                                        <input type="radio" name="jekel" value="P" />
                                                        <span class="check"></span>
                                                        Female
                                                    </label>
                                                </div>
                                            </div>

                                            <input type="submit" name="Register" value="Sign Up">
                                            <input type="reset" value="Cancel">
                                        </fieldset>
                                    </form>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
        	</div>
        </div>
    </div>
    <!-- ---------------------------------------- ISI TAB ------------------------------------- -->
    
    <footer class="dark" data-load="bawahan.html"></footer>
</body>
</html>